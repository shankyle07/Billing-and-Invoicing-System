// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyBPxKN2ojQMzOuaE5zpPTjUuKBrYE8Sbag",
  authDomain: "elective-bf69a.firebaseapp.com",
  projectId: "elective-bf69a",
  appId: "1:610601934868:web:1ba1ebdfdc2ea83175c701"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// Login function
function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  auth.signInWithEmailAndPassword(email, password)
    .then(() => {
      window.location.href = "dashboard.html";
    })
    .catch(error => {
      alert(error.message);
    });
}

// Logout function
function logout() {
  auth.signOut().then(() => {
    window.location.href = "index.html";
  });
}
